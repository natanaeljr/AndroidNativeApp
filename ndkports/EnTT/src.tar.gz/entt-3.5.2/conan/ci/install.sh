#!/bin/bash

set -e
set -x

pip install -U conan_package_tools conan
