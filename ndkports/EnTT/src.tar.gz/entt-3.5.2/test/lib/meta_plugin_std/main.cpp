#define CR_HOST

#include <cr.h>
#include <gtest/gtest.h>
#include <entt/meta/factory.hpp>
#include <entt/meta/meta.hpp>
#include <entt/meta/resolve.hpp>
#include "types.h"

TEST(Lib, Meta) {
    ASSERT_FALSE(entt::resolve_id("position"_hs));

    userdata ud{};

    cr_plugin ctx;
    ctx.userdata = &ud;
    cr_plugin_load(ctx, PLUGIN);
    cr_plugin_update(ctx);

    entt::meta<double>().conv<int>();

    ASSERT_TRUE(entt::resolve_id("position"_hs));
    ASSERT_TRUE(entt::resolve_id("velocity"_hs));

    auto pos = entt::resolve_id("position"_hs).construct(42., 3.);
    auto vel = entt::resolve_id("velocity"_hs).ctor<>().invoke();

    ASSERT_TRUE(pos && vel);

    ASSERT_EQ(pos.type().data("x"_hs).type(), entt::resolve<int>());
    ASSERT_TRUE(pos.type().data("y"_hs).get(pos).try_cast<int>());
    ASSERT_EQ(pos.type().data("x"_hs).get(pos).cast<int>(), 42);
    ASSERT_EQ(pos.type().data("y"_hs).get(pos).cast<int>(), 3);

    ASSERT_EQ(vel.type().data("dx"_hs).type(), entt::resolve<double>());
    ASSERT_TRUE(vel.type().data("dy"_hs).get(vel).convert<double>());
    ASSERT_EQ(vel.type().data("dx"_hs).get(vel).cast<double>(), 0.);
    ASSERT_EQ(vel.type().data("dy"_hs).get(vel).cast<double>(), 0.);

    ASSERT_EQ(ud.any.type(), entt::resolve<int>());
    ASSERT_EQ(ud.any.cast<int>(), 42);

    // these objects have been initialized from a different context
    pos.emplace<void>();
    vel.emplace<void>();
    ud.any.emplace<void>();

    cr_plugin_close(ctx);

    ASSERT_FALSE(entt::resolve_id("position"_hs));
    ASSERT_FALSE(entt::resolve_id("velocity"_hs));
}
