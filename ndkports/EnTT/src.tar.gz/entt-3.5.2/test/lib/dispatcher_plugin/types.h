#ifndef ENTT_LIB_DISPATCHER_PLUGIN_TYPES_H
#define ENTT_LIB_DISPATCHER_PLUGIN_TYPES_H

struct message {
    int payload;
};

struct event {};

#endif
